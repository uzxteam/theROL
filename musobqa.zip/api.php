<?php 
 
  $json = file_get_contents('http://data.gov.uz/api/v1/json/dataset/14350?access_key=baacf6f7c4c68e7fbaf0ea83e11467fe');
 

$natija = json_decode($json, true);

 ?>