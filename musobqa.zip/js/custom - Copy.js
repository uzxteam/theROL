(function($) {
    /* "use strict" */


 var eres = function(){
	
	var screenWidth = $(window).width();
		
	var setChartWidth = function(){
		
	}
	
	
	
	/* Function ============ */
		return {
			init:function(){
			},
			
			
			load:function(){
				
			},
			
			resize:function(){
			}
		}
	
	}();

	jQuery(document).ready(function(){
		eres.init();
	});
		
	jQuery(window).on('load',function(){
		eres.load();
	});

	jQuery(window).on('resize',function(){
		eres.resize();
		
	});     

})(jQuery);