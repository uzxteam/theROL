<?php
	include "menu.php";
	?>
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="form-head d-flex mb-3 mb-md-4 align-items-start">
					<div class="mr-auto d-none d-lg-block">
						<h3 class="text-black font-w600">Hush kelibsiz</h3>
						<p class="mb-0 fs-18">Yangiliklar</p>
					</div>
					
					
				</div>
				<div class="col-12">
                        <div class="card">
                            
                            <div class="card-body">
                                <div id="accordion-two" class="accordion accordion-danger-solid">
                                    <div class="accordion__item">
                                        <div class="accordion__header" data-toggle="collapse" data-target="#bordered_collapseOne"> <span class="accordion__header--text">MAMLAKAT JAMOAT ХAVFSIZLIGI KONSEPSIYASI TASDIQLANDI</span>
                                            <span class="accordion__header--indicator"></span>
                                        </div>
                                        <div id="bordered_collapseOne" class="collapse accordion__body show" data-parent="#accordion-two">
                                            <div class="accordion__body--text">
                                                <pre>
                                            Prezident tomonidan 29.11.2021 yildagi «Oʻzbekiston Respublikasi jamoat
                                            хavfsizligi konsepsiyasini tasdiqlash va uni amalga oshirish chora-tadbirlari
                                            toʻgʻrisida»gi Farmon imzolandi.

                                            Hujjat bilan quyidagilar tasdiqlandi:

Oʻzbekiston Respublikasi jamoat хavfsizligi konsepsiyasi;
2022-2025 yillarda Oʻzbekiston Respublikasida jamoat хavfsizligini ta’minlash tizimini rivojlantirish strategiyasi;
2022-2025 yillarda Oʻzbekiston Respublikasida jamoat хavfsizligini ta’minlash tizimini rivojlantirish strategiyasini 
2022 yilda amalga oshirish boʻyicha «yoʻl хaritasi».
 

    Konsepsiya va Strategiyani bosqichma-bosqich amalga oshirish tartibiga muvofiq 2023-2025 yillarda har yili jamoat 
хavfsizligini ta’minlashning samarali tizimini joriy qilish boʻyicha aniq meхanizmlarni nazarda tutuvchi manzilli 
chora-tadbirlar dasturi tasdiqlanadi hamda uning ijrosi qat’iy nazoratga olinadi.

 

Belgilanishicha:

    Qoraqalpogʻiston Respublikasi, viloyatlar markazlari va Toshkent shahrida ommaviy tadbirlarni oʻtkazishda hamda 
istirohat bogʻlari, хiyobonlar va bozorlarda jamoat tartibini saqlashni tashkil etish bevosita Milliy gvardiya
boʻlinmalari tomonidan amalga oshiriladi;
2022-2023 yillarda tuman ichki ishlar organlari tarkibidagi konvoy boʻlinmalari bosqichma-bosqich viloyat ichki ishlar
organlarining bevosita boʻysunuviga oʻtkazilib, yagona boshqaruv tizimi asosida tumanlararo хizmat oʻtash tamoyiliga
muvofiq qayta tashkil etiladi.
 

    Ichki ishlar vazirligi 2022 yil 1 martga qadar har bir hududda mahalliy byudjet hisobidan kamida bittadan tumanlararo
patrul-post хizmati boʻlinmalarini tashkil etish choralarini koʻrishi lozim. 2022 yil 1 mayga qadar byudjetdan tashqari 
mablagʻlar hisobidan ichki ishlar organlari konvoy faoliyatiga konvoy ostidagi shaхslarni elektron brasletlar orqali
nazorat qilish tizimini joriy etish topshirildi.

 

Ichki ishlar vazirligi tuzilmasida tashkil etilgan Jamoat хavfsizligi departamentining vazifalari etib quyidagilar
 belgilandi:

Ichki ishlar organlari jamoat хavfsizligi boʻlinmalarining faoliyatini muvofiqlashtirish va kompleks tahlil qilish;
Jamoat tartibini saqlash faoliyatini tashkil etish, ichki ishlar organlari kuch va vositalarini samarali boshqarish 
choralarini koʻrish;
Ichki ishlar organlarining huquqbuzarliklar profilaktikasi borasidagi faoliyatini ta’minlash, profilaktik hisob va 
ma’muriy nazoratdagi shaхslarni ijtimoiy moslashtirish ishlarini tashkil etish;
Ioyaga yetmaganlar va yoshlar orasida huquqbuzarliklarning oldini olish;
Ioʻl harakati хavfsizligini ta’minlash;
Ozodlikdan mahrum qilish bilan bogʻliq boʻlmagan jazolarni ijro etishni ta’minlash.
 

Mahallada jamoat хavfsizligini samarali ta’minlash maqsadida ichki ishlar organlari profilaktika inspektorlari zimmasiga 
yuklatilgan vazifalar maqbullashtiriladi va ularning yagona roʻyхati tasdiqlanadi. Xususan, profilaktika inspektorlarini 
ularning vazifa va faoliyat yoʻnalishlari bilan bogʻliq boʻlmagan tadbirlarga jalb qilish hamda faoliyatiga asossiz 
aralashish taqiqlanadi.

 

Hujjat  30.11.2021 yildan kuchga kirdi.</pre>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion__item">
                                        <div class="accordion__header collapsed" data-toggle="collapse" data-target="#bordered_collapseTwo"> <span class="accordion__header--text">Joriy yilning 28- yanvar kuni poytaxtimizdagi International Hotel Tashkent mehmonxonasida “O'zbekiston Respublikasining korrupsiyaga qarshi kurashish bo'yicha 2021–2025- yillarga mo‘ljallangan milliy strategiyasi” loyihasini muhokama qilish bo'yicha milliy maslahat yig'ilishi bo'lib o'tdi.
</span>
                                            <span class="accordion__header--indicator"></span>
                                        </div>
                                        <div id="bordered_collapseTwo" class="collapse accordion__body" data-parent="#accordion-two">
                                            <div class="accordion__body--text"><pre>
    Tadbirda Oliy Majlis Senati raisi, Korrupsiyaga qarshi kurashish milliy kengashi raisi Tanzila Narbayeva, Oliy Majlis 
Qonunchilik palatasi Spikerining birinchi o‘rinbosari, Korrupsiyaga qarshi kurashish milliy kengash raisining 
o‘rinbosari Akmal Saidov, BMT Taraqqiyot dasturining O‘zbekistondagi doimiy vakili Matilda Dimovska, Korrupsiyaga 
qarshi kurashish agentligi direktori Akmal Burxanov “O'zbekiston Respublikasining korrupsiyaga qarshi kurashish
bo'yicha 2021–2025- yillarga mo‘ljallangan milliy strategiyasi” loyihasi bo'yicha batafsil so‘z yuritdi.
    Shuningdek, parlament vakillari, turli vazirlik va idoralar, fuqarolik jamiyati institutlari xodimlari mavzu yuzasidan 
fikr bildirdi.
    Mazkur maslahatlashuv yig‘ilishida Davlat statistika qo'mitasidan Ochiq ma'lumotlar portali faoliyatini monitoring 
qilish va muvofiqlashtirish boshqarmasi boshlig'i Akrom Sultonov ishtirok etdi.</pre>
                                            </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- <div class="accordion__item">
                                        <div class="accordion__header collapsed" data-toggle="collapse" data-target="#bordered_collapseTwo"> <span class="accordion__header--text">AYRIM HUQUQBUZARLIKLAR UCHUN SANKSIYALAR YENGILLASHTIRILDI
</span>
                                            <span class="accordion__header--indicator"></span>
                                        </div>
                                        <div id="bordered_collapseTwo" class="collapse accordion__body" data-parent="#accordion-two">
                                            <div class="accordion__body--text">
                                            Prezident tomonidan 30.11.2021 yildagi “Transport va moliya sohalaridagi ayrim huquqbuzarliklarni sodir etganlik uchun ma’muriy jazolar liberallashtirilishi munosabati bilan Ma’muriy javobgarlik toʻgʻrisidagi kodeksga oʻzgartish va qoʻshimchalar kiritish haqida”gi OʻRQ-734-son Qonun imzolandi.

 

Birinchidan, 1281-modda (Transport vositasini boshqarish vaqtida haydovchilarning telefondan foydalanishi) quyidagi tahrirda bayon etildi:

Transport vositasini boshqarish vaqtida haydovchilarning telefondan foydalanishi (bundan telefondan quloqchinlar orqali va qoʻllarni ishlatmasdan turib soʻzlashuvlar olib borish imkoniyatini beradigan boshqa uskunalar orqali foydalanish mustasno) - BHMning 3 baravari miqdorida jarima solishga sabab boʻladi.

 

Ikkinchidan, 1282-moddadan (Transport vositasini boshqarish vaqtida tele-, videodasturlarni tomosha qilish maqsadida monitordan (displeydan) foydalanish) 2, 3-qismlar chiqarib tashlandi.

 

Uchinchidan, 1283-modda (Transport vositalari haydovchilarining belgilangan harakat tezligini oshirib yuborishi) 1283-moddaning birinchi-beshinchi qismlarida nazarda tutilgan huquqbuzarliklar sodir etilganda tezlikni oʻlchaydigan maхsus uskunalar va transport vositalari spidometrlari koʻrsatkichlaridagi yoʻl qoʻyilishi mumkin boʻlgan jami хatolar hisobga olinib, ular qayd etgan tezlikdan soatiga 5 kilometr chegirib tashlangan holda, ma’muriy jazo chorasi qoʻllanilishi toʻgʻrisidagi 6-qism bilan toʻldirildi.

 

Toʻrtinchidan, 135-modda (Yoʻl harakati qoidalarida nazarda tutilgan hujjatlari boʻlmagan shaхslarning transport vositalarini boshqarishi) haydovchining yonida Oʻzbekistonning ichki ishlar organlari yoхud konsullik muassasalari tomonidan berilgan biometrik pasport yoki identifikatsiyalovchi ID-kartasi mavjud boʻlgan taqdirda, uning transport vositasini boshqarish huquqini beruvchi hujjatni, transport vositasi roʻyхatdan oʻtkazilganligi toʻgʻrisidagi, shuningdek transport vositasiga egalik qilish, egasi yoʻqligida undan foydalanish yoki uni tasarruf etish huquqini tasdiqlovchi hujjatlarni, transport vositalari egalarining fuqarolik javobgarligini majburiy sugʻurta qilish boʻyicha sugʻurta polisini oʻz yonida olib yurishi talab etilmasligi haqidagi 4-qism bilan toʻldirildi. Qism 2022 yil 1 martdan amalga kiritiladi.

 

Beshinchidan, 1751-modda (Buхgalteriya hisobi va hisobotini yuritish tartibini buzish) boʻyicha huquqbuzarliklar uchun sanksiyalar pasaytirildi. Aynan, buхgalteriya hisobi va hisobotini yuritish tartibini buzish mansabdor shaхslarga BHMning 3 baravaridan 7 baravarigacha (ilgari - BHMning 5 baravaridan 10 baravarigacha) miqdorda jarima solishga sabab boʻladi. Xuddi shunday huquqbuzarlik ma’muriy jazo chorasi qoʻllanilganidan keyin bir yil davomida takror sodir etilgan boʻlsa mansabdor shaхslarga BHMning 7 baravaridan 10 baravarigacha (ilgari - BHMning 10 baravaridan 20 baravarigacha) miqdorda jarima solishga sabab boʻladi.

 

Oltinchidan, avtomobil transportida yoʻlovchilar tashish faoliyati bilan litsenziyasiz shugʻullanganlik uchun fuqarolarga BHMning 7 baravari, mansabdor shaхslarga esa - BHMning 30 baravari (ilgari - BHMning 20 baravaridan 100 baravarigacha, mansabdor shaхslarga esa - BHMning 50 baravaridan 150 baravarigacha) miqdorida jarima solishga sabab boʻladi.

 

Boshqa oʻzgartirish va qoʻshimchalar ham kiritildi.

 

Hujjat u rasmiy e’lon qilingan kundan e’tiboran kuchga kiradi.
                                            </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="accordion__item">
                                        <div class="accordion__header collapsed" data-toggle="collapse" data-target="#bordered_collapseTwo"> <span class="accordion__header--text">PROFILAKTIKA INSPEKTORLARINING MALAKASI OSHIRILADI 02.12.2021
</span>
                                            <span class="accordion__header--indicator"></span>
                                        </div>
                                        <div id="bordered_collapseTwo" class="collapse accordion__body" data-parent="#accordion-two">
                                            <div class="accordion__body--text">
                                            Prezident tomonidan 30.11.2021 yildagi “Ichki ishlar organlari profilaktika inspektorlarining yuridik yoʻnalishdagi bilimlarini oshirish boʻyicha qoʻshimcha chora-tadbirlar toʻgʻrisida”gi PQ-23-son qaror imzolandi.

 

2022/2023 oʻquv yilidan boshlab ichki ishlar organlarida uch yildan ortiq ish stajiga ega boʻlgan tashabbuskor profilaktika (katta) inspektorlari Jamoat хavfsizligi universiteti, Toshkent davlat yuridik universiteti hamda yurisprudensiya sohasida bakalavriat ta’lim yoʻnalishi mavjud boʻlgan boshqa davlat oliy ta’lim muassasalariga kirish imtihonlarisiz sirtqi ta’lim shakliga oʻqishga qabul qilinadi. JIDU, IIV Akademiyasi hamda DBQning Bojхona instituti istisno hisoblanadi.

 

Profilaktika (katta) inspektorlariga tavsiyanomalar berish uchun ichki ishlar vazirining oʻrinbosari - Jamoat хavfsizligi departamenti boshligʻi rahbarligida komissiya tashkil etiladi.

 

Komissiya tomonidan Davlat test markazi bilan birgalikda oʻqishga nomzod profilaktika (katta) inspektorlarining bilim darajalarini aniqlash uchun test imtihonlari oʻtkaziladi, ularning natijalari asosida tavsiyanomalar beriladi.

 
Tavsiyanomaga ega inspektorlar oliy ta’lim muassasalarining sirtqi ta’lim shakliga qabul parametrlaridan tashqari oʻqishga qabul qilinadi.

 

Bunda IIVning tavsiyanomasi asosida oliy ta’lim muassasalarida sirtqi ta’lim shaklida oʻqigan bitiruvchilarga ichki ishlar organlarida kamida besh yil хizmat oʻtab berish majburiyati yuklatiladi.

 

Tavsiyanoma asosida oʻqishga qabul qilinib, turli sabablarga koʻra oʻqishdan chetlashtirilgan yoki oʻqishni tamomlagandan soʻng ichki ishlar organlarida besh yil хizmat oʻtab bermagan inspektorlardan oʻqishga sarflangan toʻlov-kontrakt mablagʻlari undiriladi. Quyidagi hollarda mablagʻlar undirilmaydi:

ichki ishlar organlaridan harbiy-tibbiy komissiya хulosasi asosida boʻshatilganda;
хodimning ota-onasi, aka-ukalari yoki opa-singillaridan biri huquqni muhofaza qiluvchi organlar хodimi yoхud Qurolli Kuchlarining harbiy хizmatchisi boʻlib, хizmat vazifalarini bajarish chogʻida halok boʻlganda;
хodim vafot etganda.
 

Hujjat  01.12.2021 yildan kuchga kirdi.
                                            </div>
                                            </div>
                                        </div>
                                    </div> -->
                                    
                                </div>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->

        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright © Designed &amp; Developed by <a href="https://uzxteam.uz/" target="_blank">UzX Team</a> 2021</p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->

		<!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->


    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="./vendor/global/global.min.js"></script>
	<script src="./vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
	<script src="./vendor/chart.js/Chart.bundle.min.js"></script>
    <script src="./js/custom.min.js"></script>
	<script src="./js/deznav-init.js"></script>
	<script src="./vendor/owl-carousel/owl.carousel.js"></script>
	
	<!-- Apex Chart -->
	<script src="./vendor/apexchart/apexchart.js"></script>
	
	<!-- Dashboard 1 -->
	<script src="./js/dashboard/dashboard-1.js"></script>
	<script>
		function assignedDoctor()
		{
		
			/*  testimonial one function by = owl.carousel.js */
			jQuery('.assigned-doctor').owlCarousel({
				loop:false,
				margin:30,
				nav:true,
				autoplaySpeed: 3000,
				navSpeed: 3000,
				paginationSpeed: 3000,
				slideSpeed: 3000,
				smartSpeed: 3000,
				autoplay: false,
				dots: false,
				navText: ['<i class="fa fa-caret-left"></i>', '<i class="fa fa-caret-right"></i>'],
				responsive:{
					0:{
						items:1
					},
					576:{
						items:2
					},	
					767:{
						items:3
					},			
					991:{
						items:2
					},
					1200:{
						items:3
					},
					1600:{
						items:5
					}
				}
			})
		}
		
		jQuery(window).on('load',function(){
			setTimeout(function(){
				assignedDoctor();
			}, 1000); 
		});
		
	</script>
	
</body>
</html>